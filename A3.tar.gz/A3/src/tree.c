/* nickolas leipold
 * 0930626
 * assignment 3 2520
 * Due nov.7
**/

#include <stdio.h>
#include "tree.h"


Node *root; //root of the tree

int insert(char *str, Node *root)
{
  return 0;

}
